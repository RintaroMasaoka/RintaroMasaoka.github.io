# Skill Shelf

Stable, installable AI skill packages by Rintaro Masaoka.

This repository contains only packages that have been deliberately promoted
from the private working stock. It is not a mirror of the author's everyday
development environment.

## Stable packages

| Package | Version |
| --- | --- |
| Academic Writing | 0.2.2 |
| Physics Paper | 0.1.5 |
| Nogap | 0.1.0 |
| Manim | 0.1.0+codex.20260820030822 |

Each release is a detached, version-fixed snapshot promoted from the private
working stock. Updates are made by a new reviewed promotion; this repository
is never used as the working authority.

## Local installation

Download and extract `skill-shelf-stable.zip`, then register its root as a
local marketplace and install only the package you want:

```sh
codex plugin marketplace add /path/to/skill-shelf
codex plugin add academic-writing@skill-shelf
```

Claude Code uses the matching `.claude-plugin/marketplace.json` catalog.

## License

Original material in this repository is licensed under the MIT License.
Files or package components carrying a separate license notice remain under
the terms named in that notice. In particular, the `academic-writing` package
includes material licensed under CC BY 4.0; its attribution and license notice
must remain with the distributed package.
